package com.bignerdranch.android.myapplication

import android.content.Context
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Spinner
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bignerdranch.android.myapplication.databinding.ActivityMainBinding
import com.bignerdranch.android.myapplication.databinding.ItemProductBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: ProductAdapter
    private lateinit var spinner: Spinner

    private val products = listOf(
        Product(1, "Ноутбук", 99999.99, 4.5f),
        Product(2, "Мышь", 2999.99, 4.8f),
        Product(3, "Клавиатура", 8999.99, 4.2f),
        Product(4, "Монитор", 29999.99, 4.7f),
        Product(5, "Наушники", 15999.99, 4.9f),
        Product(6, "Зарядка", 1999.99, 4.0f),
        Product(7, "Чехол", 1599.99, 3.8f),
        Product(8, "Смартфон", 69999.99, 4.6f),
        Product(9, "Планшет", 39999.99, 4.4f),
        Product(10, "Колонка", 7999.99, 4.3f)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupSpinner()
        loadLastSortTypeAndApply()
    }

    private fun setupRecyclerView() {
        adapter = ProductAdapter(products)
        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }
    }

    private fun setupSpinner() {
        spinner = binding.spinnerSort
        val sortOptions = listOf(
            "По имени (А → Я)",
            "По имени (Я → А)",
            "По цене (дешевые → дорогие)",
            "По цене (дорогие → дешевые)",
            "По рейтингу (низкий → высокий)",
            "По рейтингу (высокий → низкий)"
        )

        val spinnerAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            sortOptions
        )
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = spinnerAdapter

        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: android.widget.AdapterView<*>?,
                view: android.view.View?,
                position: Int,
                id: Long
            ) {
                val sortType = when (position) {
                    0 -> SortType.BY_NAME_ASC
                    1 -> SortType.BY_NAME_DESC
                    2 -> SortType.BY_PRICE_ASC
                    3 -> SortType.BY_PRICE_DESC
                    4 -> SortType.BY_RATING_ASC
                    5 -> SortType.BY_RATING_DESC
                    else -> SortType.getDefault()
                }
                applySorting(sortType)
                saveSortType(position)
            }

            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
    }

    private fun applySorting(sortType: SortType) {
        val sortedList = when (sortType) {
            SortType.BY_NAME_ASC -> products.sortedBy { it.name }
            SortType.BY_NAME_DESC -> products.sortedByDescending { it.name }
            SortType.BY_PRICE_ASC -> products.sortedBy { it.price }
            SortType.BY_PRICE_DESC -> products.sortedByDescending { it.price }
            SortType.BY_RATING_ASC -> products.sortedBy { it.rating }
            SortType.BY_RATING_DESC -> products.sortedByDescending { it.rating }
        }
        adapter.updateProducts(sortedList)
    }

    private fun saveSortType(position: Int) {
        val sharedPref = getPreferences(Context.MODE_PRIVATE)
        with(sharedPref.edit()) {
            putInt("last_sort_position", position)
            apply()
        }
    }

    private fun loadLastSortTypeAndApply() {
        val sharedPref = getPreferences(Context.MODE_PRIVATE)
        val lastPosition = sharedPref.getInt("last_sort_position", 0)
        spinner.setSelection(lastPosition)
    }
}