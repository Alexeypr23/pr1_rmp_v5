package com.bignerdranch.android.myapplication

enum class SortType {
    BY_NAME_ASC,
    BY_NAME_DESC,
    BY_PRICE_ASC,
    BY_PRICE_DESC,
    BY_RATING_ASC,
    BY_RATING_DESC;

    companion object {
        fun getDefault() = BY_NAME_ASC
    }
}