package com.bignerdranch.android.myapplication

data class Product(
    val id: Int,
    val name: String,
    val price: Double,
    val rating: Float
)